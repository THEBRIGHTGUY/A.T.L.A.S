// Shared settings and helpers. This file must be IDENTICAL in the brain and sensor folders.
#pragma once
#include <RadioLib.h>
#include "mbedtls/md.h"

// ================= SETTINGS THAT MUST MATCH ON BOTH BOARDS =================
const char* MASTER_SECRET = "change-this-to-long-random-text";   // change it and keep it private
#define LORA_FREQ  866.5    // MHz. Use the band your board is made for, and make sure it is legal where you live
#define LORA_POWER 3        // dBm drive level (your earlier working setup used 3; the V4 amplifier boosts it)
// ===========================================================================

struct __attribute__((packed)) Packet {
  uint8_t  magic;      // 0xA5
  uint8_t  id[3];
  uint16_t seq;
  uint8_t  ok;         // bit0 soil, bit1 light, bit2 air
  uint16_t soil[7];    // raw registers: moisture, temp, EC, pH, N, P, K
  uint16_t lux;
  int16_t  airT100;
  uint16_t airH100;
  uint16_t pres10;
  uint8_t  tag[4];     // truncated HMAC-SHA256
};

void hmac256(const uint8_t* data, size_t n, uint8_t out[32]) {
  mbedtls_md_context_t c;
  mbedtls_md_init(&c);
  mbedtls_md_setup(&c, mbedtls_md_info_from_type(MBEDTLS_MD_SHA256), 1);
  mbedtls_md_hmac_starts(&c, (const uint8_t*)MASTER_SECRET, strlen(MASTER_SECRET));
  mbedtls_md_hmac_update(&c, data, n);
  mbedtls_md_hmac_finish(&c, out);
  mbedtls_md_free(&c);
}

// pairing key for a node id, derived from the master secret (8 hex chars)
String keyFor(const char* idStr) {
  String m = String("key:") + idStr;
  uint8_t h[32];
  hmac256((const uint8_t*)m.c_str(), m.length(), h);
  char b[9];
  snprintf(b, sizeof b, "%02X%02X%02X%02X", h[0], h[1], h[2], h[3]);
  return String(b);
}

#include "radio_setup.h"
